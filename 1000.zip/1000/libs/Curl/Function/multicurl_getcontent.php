<?php

if (!function_exists('curl_init')) {
  throw new Exception('Needs the CURL PHP extension.');
}
if (!function_exists('json_decode')) {
  throw new Exception('Needs the JSON PHP extension.');
}