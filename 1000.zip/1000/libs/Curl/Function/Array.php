<?php

$lista = $_GET['lista'];
$divide = explode("|", $lista);
$cc = $divide[0];
$mm = $divide[1];
$yy = $divide[2];
$cvv = $divide[3];