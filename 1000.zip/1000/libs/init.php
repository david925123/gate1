<?php

// Curl singleton
require(dirname(__FILE__) . '/Curl/Captcha.php');

// Functions